# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Opinionpoll::Application.config.secret_key_base = '85f7e164dc91b26a7d792926bee5de1171a156a6ac49f3406ded321487e5a7f45080b9d6d47f388646c820d3c003ed00b12c938814572f0551a12b02f1826853'
