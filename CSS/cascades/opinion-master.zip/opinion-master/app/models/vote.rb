class Vote < ActiveRecord::Base
	belongs_to :option
end
